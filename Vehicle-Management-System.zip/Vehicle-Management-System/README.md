# Vehicle Management System

A beginner-friendly Java console application for managing different types of vehicles.

## Features

- Add a regular car, electric car, or petrol car
- Display all vehicles
- Search for a vehicle by brand
- Remove a vehicle by brand
- Display petrol cars
- Filter petrol cars by minimum year
- Validate year and electric battery percentage
- Demonstrate inheritance, method overriding, `ArrayList`, loops, and `Iterator`

## Requirements

- Java JDK 8 or later

## How to run

Place all four `.java` files in the same folder. Open a terminal in that folder and run:

```bash
javac Main.java Car.java ElectricCar.java PetrolCar.java
java Main
```

## Classes

- `Car`: base class for vehicles
- `ElectricCar`: extends `Car` and stores battery percentage
- `PetrolCar`: extends `Car`
- `Main`: menu and application logic

## Learning project

This project was created as a Java practice project and can be extended with file storage, unit tests, and a graphical interface.
