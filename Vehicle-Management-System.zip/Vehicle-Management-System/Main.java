import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ArrayList<Car> cars = new ArrayList<>();
        Scanner input = new Scanner(System.in);
        boolean running = true;

        while (running) {
            printMenu();
            System.out.print("Choose an option: ");

            int choice;
            try {
                choice = input.nextInt();
                input.nextLine();
            } catch (Exception e) {
                System.out.println("Invalid choice. Please enter a number.");
                input.nextLine();
                continue;
            }

            switch (choice) {
                case 1:
                    addCar(cars, input);
                    break;
                case 2:
                    addElectricCar(cars, input);
                    break;
                case 3:
                    addPetrolCar(cars, input);
                    break;
                case 4:
                    displayCars(cars);
                    break;
                case 5:
                    searchCar(cars, input);
                    break;
                case 6:
                    removeCar(cars, input);
                    break;
                case 7:
                    displayPetrolCars(cars);
                    break;
                case 8:
                    displayPetrolCarsAfterYear(cars, input);
                    break;
                case 9:
                    running = false;
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Please choose a number from 1 to 9.");
            }
        }
        input.close();
    }

    private static void printMenu() {
        System.out.println("\\n=== Vehicle Management System ===");
        System.out.println("1. Add a car");
        System.out.println("2. Add an electric car");
        System.out.println("3. Add a petrol car");
        System.out.println("4. Display all vehicles");
        System.out.println("5. Search by brand");
        System.out.println("6. Remove a vehicle by brand");
        System.out.println("7. Display petrol cars");
        System.out.println("8. Display petrol cars from a year onward");
        System.out.println("9. Exit");
    }

    private static void addCar(ArrayList<Car> cars, Scanner input) {
        String brand = readBrand(input);
        int year = readYear(input);
        if (brand == null || year == -1) return;
        cars.add(new Car(brand, year));
        System.out.println("Car added successfully.");
    }

    private static void addElectricCar(ArrayList<Car> cars, Scanner input) {
        String brand = readBrand(input);
        int year = readYear(input);
        if (brand == null || year == -1) return;
        System.out.print("Battery percentage (0-100): ");
        int battery;
        try {
            battery = input.nextInt();
            input.nextLine();
        } catch (Exception e) {
            System.out.println("Invalid battery value.");
            input.nextLine();
            return;
        }
        if (!isValidBattery(battery)) {
            System.out.println("Battery must be between 0 and 100.");
            return;
        }
        cars.add(new ElectricCar(brand, year, battery));
        System.out.println("Electric car added successfully.");
    }

    private static void addPetrolCar(ArrayList<Car> cars, Scanner input) {
        String brand = readBrand(input);
        int year = readYear(input);
        if (brand == null || year == -1) return;
        cars.add(new PetrolCar(brand, year));
        System.out.println("Petrol car added successfully.");
    }

    private static String readBrand(Scanner input) {
        System.out.print("Brand: ");
        String brand = input.nextLine().trim();
        if (brand.isEmpty()) {
            System.out.println("Brand cannot be empty.");
            return null;
        }
        return brand;
    }

    private static int readYear(Scanner input) {
        System.out.print("Year (1900-2026): ");
        int year;
        try {
            year = input.nextInt();
            input.nextLine();
        } catch (Exception e) {
            System.out.println("Invalid year.");
            input.nextLine();
            return -1;
        }
        if (!isValidYear(year)) {
            System.out.println("Year must be between 1900 and 2026.");
            return -1;
        }
        return year;
    }

    private static boolean isValidYear(int year) {
        return year >= 1900 && year <= 2026;
    }

    private static boolean isValidBattery(int battery) {
        return battery >= 0 && battery <= 100;
    }

    private static void displayCars(ArrayList<Car> cars) {
        if (cars.isEmpty()) {
            System.out.println("No vehicles found.");
            return;
        }
        for (Car car : cars) {
            car.displayInfo();
        }
    }

    private static void searchCar(ArrayList<Car> cars, Scanner input) {
        System.out.print("Enter brand to search: ");
        String brand = input.nextLine().trim();
        boolean found = false;
        for (Car car : cars) {
            if (brand.equalsIgnoreCase(car.getBrand())) {
                car.displayInfo();
                found = true;
            }
        }
        if (!found) System.out.println("Vehicle not found.");
    }

    private static void removeCar(ArrayList<Car> cars, Scanner input) {
        System.out.print("Enter brand to remove: ");
        String brand = input.nextLine().trim();
        Iterator<Car> iterator = cars.iterator();
        while (iterator.hasNext()) {
            Car car = iterator.next();
            if (brand.equalsIgnoreCase(car.getBrand())) {
                iterator.remove();
                System.out.println("Vehicle removed successfully.");
                return;
            }
        }
        System.out.println("Vehicle not found.");
    }

    private static void displayPetrolCars(ArrayList<Car> cars) {
        int count = 0;
        for (Car car : cars) {
            if (car instanceof PetrolCar) {
                car.displayInfo();
                count++;
            }
        }
        if (count == 0) System.out.println("No petrol car found.");
    }

    private static void displayPetrolCarsAfterYear(ArrayList<Car> cars, Scanner input) {
        System.out.print("Display petrol cars from year: ");
        int year;
        try {
            year = input.nextInt();
            input.nextLine();
        } catch (Exception e) {
            System.out.println("Invalid year.");
            input.nextLine();
            return;
        }

        int count = 0;
        for (Car car : cars) {
            if (car instanceof PetrolCar && car.getYear() >= year) {
                car.displayInfo();
                count++;
            }
        }
        System.out.println("Number of petrol cars: " + count);
    }
}
